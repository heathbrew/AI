"""
for i in range(8):
    x = float(input("x: "))
    y = float(input("y: "))
    print(x*y)
    """
for i in range(8):
    x = float(input("x: "))
    print(x*x)    


    
